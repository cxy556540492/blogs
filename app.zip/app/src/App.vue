<template>
  <div id="app">
    <Home></Home>
  </div>
</template>
<script>
  import Home from './pages/Home/Home'

  export default {
    name: "app",
    components: {
      Home,
    }
  }
</script>
<style lang="scss">

</style>